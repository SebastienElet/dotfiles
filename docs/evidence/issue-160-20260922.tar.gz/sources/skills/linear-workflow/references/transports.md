# Linear Transport Adapters

Select a transport at runtime. The business workflow remains in its composing skill and
`linear-workflow`.

## Selection

1. Prefer an authenticated Linear connector exposed by the current agent when its current schema
   covers identity, filtered issue listing with pagination, issue details, hierarchy, blocking
   relations, links or attachments, workflow state updates, and URL attachment. Routing an issue by
   its completion evidence additionally requires listing a team's workflow states, an anchored
   partial edit of a description, and applying such an edit in the same save as a state change;
   check each and the documented whole-save failure semantics, then require the two live
   observations in [completion evidence](completion-evidence.md) before writing state. Missing the anchored guard does not disqualify the transport for
   reading and classifying — it removes the authority to write the state, which then goes to a
   human. Recording accepted residue on a closing transition also needs reading and writing issue
   comments.
2. Otherwise use the installed `linear` CLI only after its local help confirms the commands and
   `linear auth whoami` succeeds for the intended workspace.
3. Otherwise use Linear GraphQL only when authentication and the current schema are already
   available and every response is checked for transport failure, top-level errors, null required
   fields, and mutation success.
4. Stop before the first uncovered operation. Never combine partial transports unless identity and
   workspace equality are proven.

## Connector adapter

- Inspect the connector's tools in the current session; configuration or marketplace availability
  alone does not prove activation or authentication.
- If no integrated connector tool is exposed, the [official MCP authentication
  documentation](https://linear.app/docs/mcp) permits an existing API key or OAuth token in the
  bearer header to `https://mcp.linear.app/mcp`. Inspect that server's live `tools/list` before
  declaring MCP unavailable; never expose or persist the credential. The
  [2026-09-10 experiment](linear-guard-observation-2026-09-10.md) reached it this way, but found that
  `save_issue` rejects identity replacements even with a unique anchor: state writes using that
  guard remain disabled. A valid schema and a whole-save contract do not override this observation.
- Retrieve issue data and relations with structured fields. Resolve attachment URLs without
  inferring their meaning from prose.
- After a state or link mutation, retrieve the issue independently and compare the stored value.

## CLI adapter

The locally inspected `linear` 2.6.0 help (2026-09-09) exposes:

- `linear auth whoami --workspace <workspace>` for identity and authentication;
- `linear issue query --workspace <workspace> --assignee <username> --all-states --limit 0 --json`
  for an exhaustive structured list of one user's issues;
- `linear issue view <issue-id> --workspace <workspace> --json` for structured issue, hierarchy,
  inverse relations, and attachments;
- `linear issue relation list <issue-id> --workspace <workspace>` to inspect relations;
- `linear issue update <issue-id> --workspace <workspace> --state <state>` for lifecycle
  transitions;
- `linear issue link <issue-id> <pull-request-url> --workspace <workspace>` for URL attachment.

It also exposes `linear team states <team-key> --json` and full-description replacement through
`linear issue update --description` or `--description-file`. Neither is an anchored edit.
`linear api` provides GraphQL access, but the inspected `IssueUpdateInput` has `stateId` and
`description` without a patch or condition field; `issueUpdate` takes only `id` and `input`.
Evidence-based state writes remain uncovered on these inspected paths. See the
[dated inspection and limits](linear-guard-observation-2026-09-09.md); command availability is not
proof of a successful mutation or whole-save atomicity.

Run current local help again before use. This binary is a third-party Linear CLI, not an official
Linear CLI. Do not use `linear issue pr`: its installed documentation delegates to GitHub's `gh`,
so it cannot create the required Bitbucket pull request.

## Fallback limits

- An unauthenticated CLI is unavailable even when it has stored workspace names.
- A read-only connector cannot update an issue or attach a pull request.
- Do not install a plugin, add a connector, log in, or create test data merely to complete probing.
