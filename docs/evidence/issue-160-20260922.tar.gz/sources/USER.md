# USER.md — Biais et attentes de l'utilisateur

Préférences de collaboration et biais techniques stables. Identité de l'agent →
`SOUL.md` ; invariants, conventions et contrôles propres au projet → `AGENTS.md`,
rules, skills, linters, hooks ou CI.

## Acquis

Shell, git et Unix ; web moderne (JS/TS, bundlers, npm) ; infra et conteneurs
(Docker, CI/CD, réseau) ; backend et bases de données (SQL, modélisation,
transactions). Aucun rappel de fondamentaux sur ces sujets : aller au fait.

## Contexte personnel

- **Default Obsidian corpus:** `/operator/Code/brain`

## Biais techniques

- **Simplicité, testabilité, localité.** À qualité comparable, préférer la solution
  concise, facilement testable et reconstruisible par un humain, un junior ou un agent.
  Éviter les abstractions qui imposent de traverser de nombreux fichiers pour comprendre
  un comportement simple ; plusieurs éléments cohésifs peuvent rester dans le même fichier.
- **Fonctionnel et immuable par défaut.** Préférer fonctions, composition, transformations
  explicites et valeurs immuables. Dans un framework orienté classes, garder les classes à
  sa frontière et le cœur métier fonctionnel et pur. Guard clauses et early returns sont
  préférés aux imbrications ; `map`/`filter`/`reduce` expriment un résultat, `for`/`forEach`
  des effets sans résultat.
- **Architecture actée > simplicité locale.** Respecter les frontières décidées par l'équipe.
  Une contradiction certaine avec un ADR ou invariant bloque le chemin concerné ; ne pas
  créer une exception locale pour contourner une architecture qui doit être corrigée.
- **Domaine canonique.** Centraliser les décisions et invariants métier dans le domaine quand
  ils ne peuvent pas être garantis plus bas ; handlers et adapters orchestrent dépendances
  et effets de bord. Séparer modèle DB/ORM, DTO de frontière et modèle métier dès le début.
  La frontière transactionnelle suit l'invariant : repository s'il le porte seul, handler
  s'il coordonne plusieurs repositories.
- **WET et YAGNI.** Deux chemins spécifiques valent mieux qu'une abstraction hypothétique.
  Extraire quand données, invariants et évolution probable sont réellement communs. Préférer
  des APIs spécifiques au cas d'usage ; éviter booléens positionnels et généralisation précoce.
- **SSOT.** Une information structurante a une source canonique ; validation, types, clients,
  documentation ou autres représentations en dérivent. Ne jamais éditer le généré. Maintenir
  un lexique métier canonique par projet et renommer quand il évolue pour éviter les synonymes.
- **Typage métier strict.** Faire échouer au plus tôt : typage avant test, test avant runtime.
  Rendre les états invalides non représentables avec branded types, unions discriminées et
  types fermés. Préférer des types dédiés pour dates métier, montants et identifiants ; des IDs
  de domaines différents restent incompatibles. Pour la monnaie, préférer l'unité minimale
  entière aux flottants.
- **Validation aux frontières.** Parser et valider les entrées externes une fois, puis faire
  circuler des valeurs fiables ; en TypeScript, Zod est un bon défaut. Éviter `null`/`undefined`
  ambigus. Valider la configuration au démarrage et injecter un objet typé ; `process.env`
  hors frontière est un code smell.
- **TDD par défaut, preuve proportionnée.** Test avant code possédé ; pour un bug, reproduire
  d'abord la régression. Ajouter et exécuter les tests ordinaires pertinents sans confirmation.
  Un oracle maison protège un invariant possédé, pas l'implémentation d'un outil externe comme Moon.
  Avant tout nouvel oracle, chercher la validation native ou existante suffisante : parser, schéma,
  typecheck, dry-run, commande d'inspection, exécution publique, smoke test ou CI existante.
  Choisir le coût global minimal — exécution et maintenance — pour une confiance suffisante au
  regard de la criticité ; l'absence de test dédié ne justifie pas un nouvel oracle. Monter de
  l'unitaire à l'intégration, à l'E2E ou à un contrôle custom seulement si la frontière de l'invariant
  l'exige ; ne pas dupliquer la même preuve à plusieurs niveaux sans bénéfice matériel.
  DB, transaction ou mapping ORM exigent une intégration avec vraie DB lorsque la preuve leur
  appartient ; même principe pour un protocole ou autre composant. Nommer les tests selon la
  frontière exercée : une application montée in-process avec vraie DB et systèmes externes
  substitués in-memory relève de l'intégration. Réserver E2E à une frontière système assemblée,
  proche de la production ; HTTP ou une convention de framework, notamment NestJS, ne suffisent pas.
  Exception au TDD : déclaratif sans comportement propre, notamment constante, version, variable
  d'environnement ou option de commande, sans test de valeur. Pour Moon, Makefiles ou YAML, utiliser
  d'abord les oracles natifs ou existants qui détectent une erreur réelle. Un invariant de
  configuration possédé, notamment de sécurité ou de compatibilité, mérite une preuve de son
  comportement ; ne pas recopier la déclaration comme attendu ni retester le graphe ou les options
  de l'outil. Dériver l'attendu d'une autre source canonique indépendante lorsque c'est possible.
  Ne pas créer spontanément de script Bash/TypeScript, validateur, lint rule, gate CI ou test harness
  pour renforcer la validation du déclaratif. Si un manque significatif semble justifier cette
  nouvelle infrastructure, suspendre seulement sa création et demander l'avis de l'utilisateur :
  invariant possédé, source canonique, oracles considérés, preuve manquante, criticité du risque
  résiduel et contrôle envisagé. Ce checkpoint porte sur la pertinence de cette nouvelle surface de
  maintenance, pas sur les tests ordinaires du code possédé. Une gate directement demandée par
  l'utilisateur ou une autorité externe reste à implémenter ; un plan, une spécification, une ADR
  ou une revue produits par un agent dans le même flux ne constituent pas cette demande.
- **In-memory plutôt que mocks.** Pour les dépendances applicatives, préférer une implémentation
  in-memory minimale qui évolue sous la pression des tests. Tester le vrai composant lorsque
  l'invariant lui appartient, par exemple index unique ou trigger DB. Tester les invariants et
  comportements observables, jamais les détails d'implémentation ou du coverage pour lui-même.
- **État React local et dérivé.** Garder l'état au niveau le plus local qui porte réellement
  la décision ; ne pas dupliquer une valeur qui peut être dérivée d'une source de vérité existante.
  Remonter ou globaliser l'état seulement lorsqu'une coordination réelle entre plusieurs branches
  de l'UI l'exige. Considérer `useEffect` comme une frontière avec un système extérieur, pas comme
  un mécanisme normal d'orchestration de l'état React ; effets en chaîne, correctifs entre effets
  et synchronisation d'états dérivables sont des signaux de conception à reprendre.
- **Frontend testable par construction.** Les dépendances à effets d'un composant doivent pouvoir
  être substituées sans mocks globaux ni patchs de modules complexes. Ne pas imposer un mécanisme
  d'injection particulier : suivre les patterns React actuels et les conventions du projet. Avant
  de refactorer un composant historique non testé, sécuriser d'abord le comportement observable
  que le changement risque d'affecter.
- **Rien de cassé n'est toléré.** Un test intermittent est un bug : ni `retry`, ni `skip`, chercher
  la cause. Le coverage peut être un garde-fou modéré selon l'état du projet, jamais un objectif
  qui justifie des tests sans valeur.
- **DB comme verrou canonique quand possible.** Préférer contraintes déterministes en DB et
  traduire leurs erreurs en erreurs métier plutôt que maintenir un pré-check redondant. Nommer
  contraintes et index importants. Isolation tenant et autres invariants structurels doivent
  descendre au niveau le plus bas capable de les garantir.
- **ORM pour le simple, SQL typé pour le complexe.** Un accès DB dans une boucle déclenche la
  recherche d'un bulk, `JOIN`, agrégat ou chargement groupé. Corriger tôt N+1, fan-out réseau/DB
  et autres smells structurels ; mesurer les optimisations dépendantes du workload. Normaliser
  par défaut ; dénormaliser quand le ratio lecture/écriture ou une mesure le justifie.
- **Cache en dernier recours.** Optimiser d'abord schéma, index et requêtes. Introduire un cache
  seulement si charge, ratio lecture/écriture, tolérance à la fraîcheur ou SLO le justifient.
- **Migrations progressives et reprenables.** Préférer expand/contract. Découper les gros
  changements en migrations petites, atomiques, compréhensibles et rejouables autant que
  possible plutôt qu'une opération monolithique difficile à reprendre. Lorsqu'un changement
  remplace transversalement un runtime, framework, outil ou mécanisme, inventorier d'abord les
  garanties et oracles fournis par l'ancien chemin, puis établir lesquels sont conservés,
  remplacés ou explicitement abandonnés. Un pipeline vert après substitution prouve seulement les
  propriétés qu'il exerce ; il ne prouve pas l'équivalence des garanties entre l'ancien et le
  nouveau mécanisme.
- **Concurrence bornée et asynchrone.** `Promise.all` convient à un ensemble indépendant de
  taille connue ; sinon limiter explicitement la concurrence. Un fan-out DB/API est d'abord
  un signal à remplacer par batch, requête groupée ou queue. Pour les systèmes externes,
  préférer queue/worker dès que le métier le permet.
- **Jobs rejouables.** Chercher l'idempotence, rendre la progression durable et arbitrer doublon
  versus omission selon leur coût métier. Retry uniquement les opérations rejouables sur erreurs
  plausiblement transitoires ; respecter `429`/`Retry-After`. Timeouts explicites et courts ;
  un traitement réellement long devrait idéalement devenir asynchrone.
- **Erreurs applicatives stables.** Traduire ORM/framework/tiers vers des codes métier i18n ;
  pour l'inattendu, réponse générique et détail technique dans l'observabilité.
- **Nommage explicite.** Préférer les noms métier complets, sans abréviations locales ; seuls les
  acronymes techniques standard et non ambigus sont acceptables. `process`, `handle`, `manage`
  ou `execute` sont des signaux à remplacer par un verbe métier plus précis quand il existe.
  Extraire une fonction même non réutilisée si son nom clarifie une étape.
- **Standard mature à bénéfice comparable.** Favoriser les technologies largement adoptées pour
  onboarding, debug, sécurité et maintenance. Une technologie niche reste acceptable si son gain
  est concret et qu'elle reste confinée derrière une API simple.
- **Petit helper > petite dépendance.** Le biais naturel est d'installer une librairie ; le
  challenger. Si le besoin tient dans environ 30–50 lignes sans cas limites sérieux, préférer un
  helper interne. Un `common`/`shared` peut servir d'incubateur, puis extraire les groupes cohésifs
  vers des packages spécialisés quand ils émergent.
- **Monolithe modulaire par défaut.** Pour démarrer ou avec une équipe unique, préférer un
  monolithe aux frontières strictes. Les microservices doivent répondre à un besoin réel
  d'autonomie organisationnelle ou de déploiement. Lecture cross-module possible via contrat
  explicite ; écriture uniquement via le module propriétaire.
- **Service avant pureté.** Sur incident, restaurer le service rapidement et tracer la cause
  racine ; ne pas pérenniser un workaround d'un défaut possédé. Refactorer le chemin directement
  concerné si cela simplifie la feature ; demander avant d'élargir aux abstractions voisines.
- **Réécriture selon le risque et la coordination.** Sur un chemin en production, utilisé par des
  clients ou critique, préférer une évolution progressive et vérifiable. Avant mise en production,
  sans utilisateurs et sur une zone peu partagée, accepter une réécriture cohérente plus large si
  elle réduit réellement le coût de coordination et de review. Si d'autres développeurs modifient
  activement la même zone, coordonner le changement ou attendre un point de synchronisation.
- **Exploitation intégrée.** Logs structurés et contextualisés sur les chemins critiques ; éviter
  `console.log` et le bruit. Préférer migrations, handlers, workers, backoffice ou CLI supportée
  aux scripts ad hoc ; un script one-shot reste un dernier recours. Supprimer le code mort : Git
  conserve l'historique.
- **Compatibilité selon le contrat de déploiement.** Si producteurs et consommateurs sont
  déployés ensemble, refactorer vite tous les consommateurs. Maintenir une compatibilité stricte
  pour applications mobiles, clients externes ou versions indépendantes.

## Mode de travail

- **Lecture autonome, écriture contrôlée.** Explorer, rechercher et vérifier librement.
  Une tâche évidente peut être implémentée directement ; sinon, demander validation avant
  toute écriture persistante dès que périmètre, architecture ou hypothèse sont incertains.
- **Validation concise.** Donner le périmètre, les changements principaux, hypothèses,
  incertitudes et une recommandation. Pour un changement complexe, préférer une vue du
  diff conceptuel : arborescence, schéma ASCII, maquette CLI/UI ou équivalent.
- **Affirmations alignées sur le résultat.** À la fin d'un changement, vérifier que les affirmations
  factuelles présentes dans la PR et dans la documentation touchée correspondent au code courant.
  Ne pas rendre la documentation exhaustive par principe : corriger ou retirer uniquement les
  affirmations devenues fausses, trop fortes ou contradictoires avec l'implémentation.
- **Spécifier le résultat, redécouvrir l'implémentation.** Une issue ou spécification doit être
  précise sur le comportement attendu, les contraintes produit, les états visibles, les designs
  ou composants à respecter et les critères d'acceptation, sans figer architecture, fichiers ou
  étapes techniques. L'agent qui implémente refait sa discovery avec l'état courant du code, de
  la documentation et des outils ; ne pas l'ancrer sur une solution technique préparée plus tôt.
- **Plan seulement quand il aide.** Sur une tâche simple et stable, plan court si utile.
  Sur une tâche complexe, explorer sans figer tôt la solution et proposer des issues pour
  les blocages découverts.
- **Découpage de travail ≠ découpage de PR.** Découper une tâche lorsque cela borne
  utilement le contexte d'un agent, permet une session fraîche ou ouvre du parallélisme.
  Les sous-tâches n'ont pas à correspondre 1:1 aux PR : plusieurs peuvent converger dans
  une même PR lorsque cela réduit le coût de review ou accélère la livraison.
- **Rester focalisé.** Prioriser blocages, réduction d'incertitude, fonctionnel, puis dette.
  Une dette non bloquante ne mérite une proposition d'issue que si elle touche directement
  la tâche ; ne jamais l'implémenter sans décision explicite.
- **Continuer ce qui est indépendant.** Un blocage local n'arrête pas un travail sans
  dépendance de code ni dépendance architecturale avec lui.
- **Relais sans ancrage.** Pour un nouvel agent, transmettre faits, contraintes et pistes
  invalidées ; ne transmettre des sources précises que si leur pertinence est certaine,
  et ne pas pré-écrire la solution.
- **Contexte comme ressource.** Si la session devient trop chargée pour un nouveau correctif,
  préférer une issue et un prompt concis pour une nouvelle session. ~60 % de contexte visible
  est un signal d'alerte, pas une limite absolue.
- **Barre de vérification.** Lint, types, tests et CI verts restent la barre par défaut, mais ne
  constituent pas une revue.

## Review

- Garder les retours courts, hiérarchisés et centrés sur la PR.
- Une revue demande la suppression d'une gate qui recopie une déclaration ou teste un outil externe ;
  elle ne demande jamais d'étendre ses assertions pour la rendre plus exhaustive.
- **Style non bloquant.** Signaler la sur-abstraction sans en faire un motif de blocage ; la
  décision reste à l'auteur.
- Un constat important peut devenir une issue. S'il est simple et déjà compris, le reviewer
  peut le corriger immédiatement ; sinon, proposer une issue et un prompt pour un agent frais.
- Une migration de framework trop mécanique est suspecte : repartir des invariants et garanties
  attendues avant de transposer l'ancienne implémentation ou ses paradigmes.

## Points de vigilance

Signaler systématiquement les cas limites et conséquences non voulues du changement :

1. **Gestion d'erreur incomplète** — échecs, timeouts, retours vides/nuls. Sur une écriture
   externe : idempotence nommée, ordre attendu, écriture atomique des valeurs dérivées ; une
   entrée inconnue reste brute, quarantinée et rejouable.
2. **Nommage et lisibilité** — proposer directement de meilleurs noms. Une forte densité de
   commentaires sur le chemin de la tâche est un signal de conception ; proposer une issue,
   sans élargir automatiquement le travail.
3. **Dépendance de trop** — si quelques dizaines de lignes sans cas limites sérieux suffisent,
   proposer d'abord cette option. Pour l'orchestration de promesses, vérifier si les primitives
   natives suffisent avant `p-limit`, `p-map`, `p-queue` ou équivalent.

## Expériences en cours

- Avant une modification non triviale, annoncer les zones prévues et signaler une expansion
  matérielle du périmètre.
